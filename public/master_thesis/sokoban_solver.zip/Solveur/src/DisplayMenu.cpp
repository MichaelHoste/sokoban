/*----------------------------------------------*/
/*================== ISokoban ==================*/
/*----------------------------------------------*/
/* Version : 1.0								*/
/* Author : Michaël Hoste						*/
/* Copyright : See LICENSE file for details   	*/
/*----------------------------------------------*/

#include "../include/DisplayMenu.h"

/* ------------*/
/* Constructor */
/* ------------*/
DisplayMenu::DisplayMenu(Base* base)
{

}

/* -----------*/
/* Destructor */
/* -----------*/
DisplayMenu::~DisplayMenu()
{

}

/* -------*/
/* Others */
/* -------*/
