/*----------------------------------------------*/
/*================== ISokoban ==================*/
/*----------------------------------------------*/
/* Version : 1.0								*/
/* Author : Michaël Hoste						*/
/* Copyright : See LICENSE file for details   	*/
/*----------------------------------------------*/

#include "../include/Display.h"

/* ------------*/
/* Constructor */
/* ------------*/
Display::Display()
{

}

/* -----------*/
/* Destructor */
/* -----------*/
Display::~Display()
{

}
