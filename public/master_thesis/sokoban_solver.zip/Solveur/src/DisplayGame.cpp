/*----------------------------------------------*/
/*================== ISokoban ==================*/
/*----------------------------------------------*/
/* Version : 1.0								*/
/* Author : Michaël Hoste						*/
/* Copyright : See LICENSE file for details   	*/
/*----------------------------------------------*/

#include "../include/DisplayGame.h"

/* ------------*/
/* Constructor */
/* ------------*/
DisplayGame::DisplayGame(Base* base)
{

}

/* -----------*/
/* Destructor */
/* -----------*/
DisplayGame::~DisplayGame()
{

}

/* -------*/
/* Others */
/* -------*/
